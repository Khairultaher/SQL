--READ COMMITTED SNAPSHOT: SESSION 1

--SESSION 1a
USE AdventureWorks
GO

ALTER DATABASE AdventureWorks
SET READ_COMMITTED_SNAPSHOT ON
GO
/* Note that we must first turn on 
Read Committed Snapshot on a database 
before it can be used. This tells 
SQL Server to set up the virtual 
snapshot environment in TempDB. */

SELECT EmployeeID, VacationHours
FROM HumanResources.Employee
WHERE EmployeeID = 4
/* Note that the employee with 
EmployeeID 4 has 48 hours of vacation 
hours before any transactions begin. */

SET TRANSACTION ISOLATION LEVEL READ COMMITTED
GO

BEGIN TRANSACTION

--SWITCH TO SESSION 2a

--SESSION 1b
SELECT EmployeeID, VacationHours
FROM HumanResources.Employee
WHERE EmployeeID = 4
/* Note that the update in Session 2 is not 
available here. The transaction has not
committed and so this transaction continues to 
get its data from the original snapshot. */

--SWITCH TO SESSION 2b

--SESSION 1c
SELECT EmployeeID, VacationHours
FROM HumanResources.Employee
WHERE EmployeeID = 4
/* Note that the changes committed in Session 2 
are now available here. The Read Committed 
Transaction Isolation Level allows this 
transaction to read committed data, whereas the 
Snapshot Isolation Level would still be reading 
from the versioned row in TempDB at this point. */

UPDATE HumanResources.Employee
SET VacationHours = VacationHours + 8
WHERE EmployeeID = 4
/* Note that this statement failed under Snapshot 
Isolation, because it attempts to modify data 
that have been modified by another transaction. 
But with Read Committed Snapshot Isolation, it 
succeeds. */

COMMIT TRANSACTION

/*

REAL WORLD SCENARIO: (See Session 1c in Example 5.) 
This time, when the first passenger refreshes the 
screen to see if any changes have been made, seat 
21C is no longer available.

*/

