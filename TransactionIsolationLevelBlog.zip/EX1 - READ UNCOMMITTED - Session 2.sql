--READ UNCOMMITTED: SESSION 2

--SESSION 2a
USE AdventureWorks
Go

BEGIN TRANSACTION

UPDATE HumanResources.Employee
SET ManagerID = 12
WHERE EmployeeID = 1

SELECT EmployeeID, ManagerID
FROM HumanResources.Employee
WHERE EmployeeID = 1
/* Note that the ManagerID has been updated to 12, and 
that the transaction has not yet committed. 

(Also note for later that this isolation level allows 
a transaction to update data that have been read by another 
transaction. The transaction in Session 1 read the row 
of EmployeeID 1 and we just changed that row here in 
the transaction in Session 2.)
*/

--SWITCH TO SESSION 1b

--SESSION 2b
ROLLBACK TRANSACTION

/*
REAL WORLD SCENARIO: (See the ATM example in the blog
post.) Your family member deposits $1,000 
into your mutual account. Seeing that balance, you 
decide to increase the amount of your transfer, but 
your family member�s transaction is rolled back and you 
end up putting the account into a negative balance. 
*/