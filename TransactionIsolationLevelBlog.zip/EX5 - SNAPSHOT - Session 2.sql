--SNAPSHOT: SESSION 2

--SESSION 2a
USE AdventureWorks
GO

BEGIN TRANSACTION

UPDATE HumanResources.Employee
SET VacationHours = VacationHours - 8
WHERE EmployeeID = 4
GO

SELECT VacationHours
FROM HumanResources.Employee
WHERE EmployeeID = 4
GO
/* Note that the update succeeded. Keep 
in mind that that change has not yet 
been committed. */

--SWITCH TO SESSION 1b

--SESSION 2b
COMMIT TRANSACTION
GO

--SWITCH TO SESSION 1c
