--REPEATABLE READ: SESSION 1

--SESSION 1a
USE AdventureWorks
Go

SET TRANSACTION ISOLATION LEVEL REPEATABLE READ
Go

BEGIN TRANSACTION

SELECT EmployeeID, ManagerID
FROM HumanResources.Employee
WHERE EmployeeID = 1
/* Note that we are reading the row of EmployeeID 1. */

--SWITCH TO SESSION 2a

--SESSION 1b
ROLLBACK TRANSACTION

--SWITCH TO SESSION 2b