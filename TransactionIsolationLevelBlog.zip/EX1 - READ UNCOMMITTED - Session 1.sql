--READ UNCOMMITTED: SESSION 1

--SESSION 1a
USE AdventureWorks
Go

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
Go

BEGIN TRANSACTION

SELECT EmployeeID, ManagerID
FROM HumanResources.Employee
WHERE EmployeeID = 1
/* Note that the ManagerID is 16 for EmployeeID 1. */

--SWITCH TO SESSION 2a

--SESSION 1b
SELECT EmployeeID, ManagerID
FROM HumanResources.Employee
WHERE EmployeeID = 1
/* Note that the update made in Session 2 is visible 
in Session 1 even though it has not yet been 
committed in Session 2! This is known as a dirty read,
because the data we see is not yet "real." */

ROLLBACK TRANSACTION

--SWITCH TO SESSION 2b


