--SERIALIZABLE: SESSION 2

--SESSION 2a
USE AdventureWorks
Go

BEGIN TRANSACTION

UPDATE Production.Location
SET CostRate = 2.0
WHERE LocationID = 2
/* Note that the Repeatable Read Transaction 
Isolation Level does not allow any updates
on a row that has been read, even if that row
is part of a range. */


INSERT Production.Location (Name, Availability, CostRate, ModifiedDate)
VALUES ('NewLoc1', 1.5, $5.00, GETDATE())
/* Note that even though this insert would change the 
results of the SELECT in Session 1, it is allowed 
by the Repeatable Read Transaction Isolation Level. 
While the Repeatable Read Transaction Isolation Level
does not allow updates to a row that has 
been read, it does not prevent inserts into a range that
has been read, effectively allowing non-repeatable reads
in that range. 

REAL WORLD SCENARIO: A transaction needs to calculate the 
total value of inventory in one step and then use that 
total in another step to calculate the percentages of 
that total that each inventory category represents. After 
all of inventory is read in the first step, a new 
inventory item is inserted into one of the categories by 
another transaction before the second step can be started 
in the first transaction. The percentages calculated in 
the second step will now be incorrect.

*/

ROLLBACK TRANSACTION

--SWITCH TO SESSION 1b

--SESSION 2b
BEGIN TRANSACTION

INSERT Production.Location (Name, Availability, CostRate, ModifiedDate)
VALUES ('NewLoc1', 1.5, $5.00, GETDATE())
/* Note that the Serializable Transaction 
Isolation Level does not allow the transaction 
in Session 2 to insert a new row into a range
of data that has been read in the transaction 
in Session 1. 

REAL WORLD SCENARIO: (See Session 2a.) The second 
transaction cannot access inventory since all 
inventory records have been read by the first 
transaction. The results in step 1 are now 
accurate.

*/

--SWITCH TO SESSION 1c

--SESSION 2c
/* Note that the Insert completes now that 
the transaction in Session 1 has completed. */

ROLLBACK TRANSACTION



