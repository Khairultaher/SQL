--REPEATABLE READ: SESSION 2

--SESSION 2a
USE AdventureWorks
Go

BEGIN TRANSACTION

UPDATE HumanResources.Employee
SET ManagerID = 12
WHERE EmployeeID = 1
/* Note that the transaction in Session 2 is 
not allowed to update data that have been read 
by the transaction in Session 1. This is 
because the Repeatable Read Isolation Level makes 
sure that all reads of unchanged data are 
repeatable; in other words, reads of the same 
data produce the same values. 

REAL WORLD SCENARIO: (See Session 2a in the previous
example.) When the second passenger requests 
the seating chart, he is told to try 
again at a later time.

*/

--SWITCH TO SESSION 1b

--SESSION 2b
SELECT EmployeeID, ManagerID
FROM HumanResources.Employee
WHERE EmployeeID = 1
/* Note that the update can go forward now that the 
transaction in Session 1 has completed. */

ROLLBACK TRANSACTION



