--READ COMMITTED: SESSION 2

--SESSION 2a
USE AdventureWorks
GO

BEGIN TRANSACTION

UPDATE HumanResources.Employee
SET ManagerID = 12
WHERE EmployeeID = 1

SELECT EmployeeID, ManagerID
FROM HumanResources.Employee
WHERE EmployeeID = 1
/* Note that the ManagerID has been updated to 12, and 
that the transaction has not yet committed. 

(Also note 
for later that this isolation level allows a transaction 
to update data that have been read by another 
transaction. The transaction in Session 1 read the row 
of EmployeeID 1 and we just changed that row here in 
the transaction in Session 2.)

REAL WORLD SCENARIO: Two passengers on the same flight 
want to reserve the same seat. The first passenger pulls 
up the seating chart (this is a read of the data). As 
she thinks about which seat to select, the second 
passenger also pulls up the seating chart and decides to 
go ahead and select seat 21C. The first passenger 
eventually decides to select 21C, also. When they arrive 
on their flight, they both claim the same seat. A flight 
attendant checks the seating chart and sees that the 
seat is registered to the second passenger. The update 
to the seating chart made by the first passenger was 
overwritten by the update made by the second passenger. 
This is known as a �lost update.�
*/

--SWITCH TO SESSION 1b

--SESSION 2b
ROLLBACK TRANSACTION

--SWITCH TO SESSION 1c