--READ COMMITTED: SESSION 1

--SESSION 1a
USE AdventureWorks
GO

SET TRANSACTION ISOLATION LEVEL READ COMMITTED
Go

BEGIN TRANSACTION

SELECT EmployeeID, ManagerID
FROM HumanResources.Employee
WHERE EmployeeID = 1
/* Note that the ManagerID is 16 for EmployeeID 1. */

--SWITCH TO SESSION 2a

--SESSION 1b
SELECT EmployeeID, ManagerID
FROM HumanResources.Employee
WHERE EmployeeID = 1
/* Note that the transaction in Session 1 is not allowed 
to read data that are in the process of updating (updated
but not yet committed in Session 2). */

--SWITCH TO SESSION 2b

--SESSION 1c
SELECT EmployeeID, ManagerID
FROM HumanResources.Employee
WHERE EmployeeID = 1
/* Note that the transaction in Session 1 is now allowed
to read data released by the transaction in Session 2
that has completed. (In this case, the transaction in 
Session 2 was rolled back, so we see the data as they 
were before that transaction started (ManagerID = 16). 
If the transaction in Session 2 had been committed, the 
ManagerID for EmployeeID 1 would have shown up as 12 
here, instead.) 

REAL WORLD SCENARIO: (See ATM example in the blog post.)
Your family member deposits $1,000 
into your mutual account. When you attempt to access the 
same account before your family member�s transaction 
completes, you are asked to wait or try again at a later 
time.
*/

ROLLBACK TRANSACTION