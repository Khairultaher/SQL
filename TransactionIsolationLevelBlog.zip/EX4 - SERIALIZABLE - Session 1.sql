--SERIALIZABLE: SESSION 1

--SESSION 1a
USE AdventureWorks
Go

SET TRANSACTION ISOLATION LEVEL REPEATABLE READ
Go
/* Note that we start with the Repeatable Read 
Transaction Isolation Level. */

BEGIN TRANSACTION

SELECT *
FROM Production.Location
/* Note that we read a range of data with this
SELECT statement. */

--SWITCH TO SESSION 2a

--SESSION 1b
ROLLBACK TRANSACTION

SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
/* Note that we now switch to the Serializable
Transaction Isolation Level. */

BEGIN TRANSACTION

SELECT *
FROM Production.Location
/* Note that we perform the same read as above when
we were using the Repeatable Read Transaction 
Isolation Level. */

--SWITCH TO SESSION 2b

--SESSION 1c
ROLLBACK TRANSACTION

--SWITCH TO SESSION 2c