--SNAPSHOT: SESSION 1

--SESSION 1a
USE AdventureWorks
Go

ALTER DATABASE AdventureWorks
SET ALLOW_SNAPSHOT_ISOLATION ON
GO 
/* Note that we must first turn on Snapshot 
Isolation on a database before it can be 
used in a transaction. This tells SQL Server 
to set up the virtual snapshot environment 
in TempDB. */

SELECT EmployeeID, VacationHours
FROM HumanResources.Employee
WHERE EmployeeID = 4
GO
/* Note that the employee with EmployeeID 4 
has 48 hours of vacation hours before any 
transactions begin. */

SET TRANSACTION ISOLATION LEVEL SNAPSHOT
GO

BEGIN TRANSACTION

--SWITCH TO SESSION 2a

--SESSION 1b
SELECT EmployeeID, VacationHours
FROM HumanResources.Employee
WHERE EmployeeID = 4
GO
/* Note that the update in Session 2 is not 
available here. This transaction 
continues to get its data from the snapshot 
taken when the transaction started. */

--SWITCH TO SESSION 2b

--SESION 1c
SELECT EmployeeID, VacationHours
FROM HumanResources.Employee
WHERE EmployeeID = 4
GO
/* Note that the changes committed in the 
transaction in Session 2 are still not 
available here. This transaction is still 
reading from the snapshot (versioned row 
in TempDB). In the next example, this will 
be different. */

UPDATE HumanResources.Employee
SET VacationHours = VacationHours + 8
WHERE EmployeeID = 4
GO
/* Note that this transaction is not allowed 
to even try to update data that have been 
updated in another transaction. When an 
attempt is made to do that, the transaction 
making the attempt is rolled back and 
terminated with an error message. */

SELECT EmployeeID, VacationHours
FROM HumanResources.Employee
WHERE EmployeeID = 4
GO
/* Note that now that this transaction has 
terminated, we see the results of the update 
committed in session 1. 

REAL WORLD SCENARIO: (See SESSION 2a in 
Example 2.) After the second passenger has 
committed his reservation for seat 21C, 
the first passenger refreshes the screen to 
see if any changes have been made. The 
first passenger has no problem accessing the 
data, but the reservation made by the second 
passenger doesn�t show up and seat 21C still 
shows available. When the first passenger 
tries to change her reserved seat to seat 
21C, she is taken to the previous 
screen and a message informs her to try 
again at a later time.

*/

UPDATE HumanResources.Employee
SET VacationHours = VacationHours + 8
WHERE EmployeeID = 4
/* Let�s set the data back to its original 
state for the next example. */



